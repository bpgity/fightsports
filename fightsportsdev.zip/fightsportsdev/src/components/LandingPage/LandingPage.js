import React, { Component } from 'react';

class LandingPage extends Component {
  render() {
    return (
      <div>
        <h1>Landing Page</h1>
      </div>
    );
  }
}

export default LandingPage;
